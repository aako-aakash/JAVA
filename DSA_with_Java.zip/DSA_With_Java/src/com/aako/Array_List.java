package com.aako;

public class Array_List {
	public static void main(String [] args) {
		int[] arr= {10,20,30,40,50,60,70,80,90,100};
		System.out.println(arr[3]);
		for(int i=0;i<arr.length;i++) {
			System.out.print(arr[i]+" ");
		}
	}
}
