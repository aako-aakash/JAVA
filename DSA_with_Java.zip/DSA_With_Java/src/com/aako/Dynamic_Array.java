package com.aako;

import java.util.ArrayList;
public class Dynamic_Array {

	public static void main(String[] args) {
		
		ArrayList<Integer> list=new ArrayList<Integer>();
		list.add(12);
		list.add(14);
		list.add(17);
		list.add(19);
		list.add(23);
		
		System.out.println(list);
		System.out.println("Size of the list: "+ list.size());

	}

}
