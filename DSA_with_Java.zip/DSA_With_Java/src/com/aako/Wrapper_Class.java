package com.aako;





public class Wrapper_Class{
	public static void main(String[] args) {
		
		//int a=10;//Primitive
		
		
		Integer int1=new Integer(27);
		System.out.println(int1);
		
		//Wrapper Class
		Integer i=37;
		System.out.println(i);
		
	}
}
