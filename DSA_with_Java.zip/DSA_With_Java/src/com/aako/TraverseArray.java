
package com.aako;

public class TraverseArray {
	
	//int[] arr= {11,12,13,14,15,16,17,18,19,20};
	public static void main(String[] args) {
		int[] arr= {11,12,13,14,15,16,17,18,19,20};
		for(int i=0;i<arr.length;i++) {
			System.out.print(arr[i]+" ");
		}
	}

}
